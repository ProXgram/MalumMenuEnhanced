using UnityEngine;
using System;

namespace MalumMenu;

public class MovementTab : ITab
{
    public string name => "Movement";

    public void Draw()
    {
        GUILayout.BeginVertical(GUILayout.Width(MenuUI.windowWidth * 0.425f));

        DrawGeneral();

        GUILayout.Space(15);

        DrawTeleport();

        GUILayout.EndVertical();
    }

    private void DrawGeneral()
    {
        // Do not let the speed slider save a temporary sprint boost as base speed.
        MovementAutomation.Pause();
        SprintHandler.Reset();
        CheatToggles.noClip = GUILayout.Toggle(CheatToggles.noClip, " NoClip");

        CheatToggles.invertControls = GUILayout.Toggle(CheatToggles.invertControls, " Invert Controls");

        try
        {
            if (PlayerControl.LocalPlayer.Data.IsDead)
            {
                PlayerControl.LocalPlayer.MyPhysics.GhostSpeed = GUILayout.HorizontalSlider(PlayerControl.LocalPlayer.MyPhysics.GhostSpeed, 0f, 20f, GUILayout.Width(250f));
                Utils.SnapSpeedToDefault(0.05f, true);
                GUILayout.Label($"Current Speed: {PlayerControl.LocalPlayer?.MyPhysics.GhostSpeed} {(Utils.IsSpeedDefault(true) ? "(Default)" : "")}");
            }
            else
            {
                PlayerControl.LocalPlayer.MyPhysics.Speed = GUILayout.HorizontalSlider(PlayerControl.LocalPlayer.MyPhysics.Speed, 0f, 20f, GUILayout.Width(250f));
                Utils.SnapSpeedToDefault(0.05f);
                GUILayout.Label($"Current Speed: {PlayerControl.LocalPlayer?.MyPhysics.Speed} {(Utils.IsSpeedDefault() ? "(Default)" : "")}");
            }
        } catch (NullReferenceException) {}

        GUILayout.Space(12f);
        CheatToggles.sprint = GUILayout.Toggle(CheatToggles.sprint, " Hold to Sprint");
        GUILayout.Label("Hold " + MalumMenu.sprintKeybind.Value + " with the menu closed.");
        if (GUILayout.Button("Sprint key: " + MalumMenu.sprintKeybind.Value, GUILayout.Width(250f)))
        {
            var keys = new[] { "LeftShift", "RightShift", "LeftControl", "RightControl" };
            var index = Array.IndexOf(keys, MalumMenu.sprintKeybind.Value);
            MalumMenu.sprintKeybind.Value = keys[(index + 1) % keys.Length];
        }
        var multiplier = Mathf.Round(GUILayout.HorizontalSlider(MalumMenu.sprintMultiplier.Value,
            1f, 4f, GUILayout.Width(250f)) * 10f) / 10f;
        if (!Mathf.Approximately(multiplier, MalumMenu.sprintMultiplier.Value))
            MalumMenu.sprintMultiplier.Value = multiplier;
        GUILayout.Label($"Sprint boost: {multiplier:0.0}x");
        GUILayout.Label("Works in lobbies and rounds. Close chat to sprint.");
    }

    private void DrawTeleport()
    {
        GUILayout.Label("Teleport", GUIStylePreset.TabSubtitle);

        CheatToggles.teleportCursor = GUILayout.Toggle(CheatToggles.teleportCursor, " to Cursor");

        CheatToggles.teleportPlayer = GUILayout.Toggle(CheatToggles.teleportPlayer, " to Player");
    }
}
